public interface PlayerPanel {
	public void initialize();
	public void setCardGUI();
}
